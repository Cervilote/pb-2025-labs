whining dog
