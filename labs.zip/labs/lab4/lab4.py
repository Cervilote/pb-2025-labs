import random

a=[1,2,3,4,5,6,7,8,9,10]
b=a.index(3)
a[b]=30
print(a)

aa=[1,2,3,4,5]
for x in aa: aa[x-1]=aa[x-1]**2
print(aa)

aaa=[1,4,6,8,9,10]
print(len(aaa)/max(aaa))

tur=(1,3,4,2)
for x in tur:
    if type(x) in (int,float):
        tur=sorted(tur)
print(tur)

ss={
    'манго': 250,
    "сардины": 340,
    'сырок': 3990,
    }
print('максимальной:',max(ss))
print('минимальной:',min(ss))

ter=['mango','beer','solo']
terr=dict(zip(ter,ter))
print(terr)

eng={'mango':'манго',
    'six':'шесть',
    'seven':'семь',
    'dude':'чувак'}
n=input('введите англ слово:')
print(eng[n])

n={'Ножницы': 1,
   'Бумага': 2,
   'Камень': 3,
   'Ящерица': 4,
   'Спок': 5,}
def key(z,u):
    for k,v in z.items():
        if v == u:
            return k
n1=(n[input('введите ваш вариант: ')])
n2=random.randint(1,5)
print('вариант противника:',key(n,n2))
if (n1==1):
    if (n2==2 or n2==4):
        print("победа!")
    if (n2==5 or n2==3):
        print("проиграл")
    else: print('ОПа!')
if (n1==2):
    if (n2==3 or n2==5):
        print("победа!")
    if (n2==1 or n2==4):
        print("проиграл")
    else: print('ОПа!')
if (n1==3):
    if (n2==4 or n2==1):
        print("победа!")
    if (n2==2 or n2==5):
        print("проиграл")
    else: print('ОПа!')
if (n1==4):
    if (n2==5 or n2==2):
        print("победа!")
    if (n2==3 or n2==1):
        print("проиграл")
    else: print('ОПа!')
if (n1==5):
    if (n2==1 or n2==3):
        print("победа!")
    if (n2==4 or n2==2):
        print("проиграл")
    else: print('ОПа!')


