def conv(a,b):
    if a[-1]=='s' and b=='s':
        return a[:-1]+b
    if a[-1]=='s' and b=='m':
        return str(round(int((a[:-1]),2)/60,3))+b
    if a[-1]=='s' and b=='h':
        return str(round(int((a[:-1]))/(60*60),3))+b
    if a[-1]=='m' and b=='s':
        return str(round(int((a[:-1]))*60,3))+b
    if a[-1]=='m' and b=='m':
        return str(round(int((a[:-1])),3))+b
    if a[-1]=='m' and b=='h':
        return str(round(int((a[:-1]))/60,3))+b
    if a[-1]=='h' and b=='s':
        return str(round(int((a[:-1]))*60*60,3))+b
    if a[-1]=='h' and b=='m':
        return str(round(int((a[:-1]))*60,3))+b
    if a[-1]=='h' and b=='h':
        return str(round(int(a[:-1]),3))+b
print(conv(input(),input()))

def vklad(a,n):
    plus=min(a//10000*0.003,0.05)
    if n<=3:
        s1=0.03
        summ = a * (1 + s1 + plus) ** n
    elif n<=6:
        s2=0.05
        s1 = 0.03
        summ = a * (1 + s1 + plus) ** n
        summ = summ * (1 + s2 + plus) ** n-3
    else:
        s3=0.02
        s1 = 0.03
        s2=0.05
        summ = a * (1 + s1 + plus) ** n
        summ = summ * (1 + s2 + plus) ** n-3
        summ = summ * (1 + s3 + plus) ** n-6
    otv=summ-a
    return round(otv,2)
print(vklad(int(input('введите сумму:')),int(input('введите количество лет:'))))

def prime(n):
    for i in range(2,n):
        if n % i == 0:
            return False
    return True
def count_primes(n,b):
    if n>b:
        return 'неверно введено'
    primes = []
    for i in range(n,b):
        if prime(i):
            primes.append(i)
    if len(primes) == 0:
        return 'нет чисел в диапазоне'
    return ' '.join(map(str,primes))
print(count_primes(int(input('от:')),int(input('до:'))))


def matrix():
    n = int(input("Введите размер матрицы (n > 2): "))
    if n <= 2:
        print("Ошибка: размер матрицы должен быть больше 2.")
        return
    print("Введите элементы первой матрицы (по строкам, числа через пробел):")
    matrix1 = []
    for i in range(n):
        stroka = list(map(float, input().split()))
        if len(stroka) != n:
            print(f"Ошибка: в строке должно быть {n} чисел.")
            return
        matrix1.append(stroka)
    print("Введите элементы второй матрицы (по строкам, числа через пробел):")
    matrix2 = []
    for i in range(n):
        stroka = list(map(float, input().split()))
        if len(stroka) != n:
            print(f"Ошибка: в строке должно быть {n} чисел.")
            return
        matrix2.append(stroka)
    result = []
    for i in range(n):
        result_stroka = []
        for j in range(n):
            result_stroka.append(matrix1[i][j] + matrix2[i][j])
        result.append(result_stroka)
    print("Результат:")
    for stroka in result:
        print(" ".join(map(str, stroka)))
matrix()

def polidrom(a):
    a=a.replace(' ','')
    a=a.lower()
    if a==a[::-1]:
        return 'yes'
    else:
        return 'no'
print(polidrom(input('vvedite text:')))




